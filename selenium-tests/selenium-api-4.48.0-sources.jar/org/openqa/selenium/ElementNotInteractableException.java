// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

package org.openqa.selenium;

/**
 * Thrown to indicate that although a {@link WebElement} is present on the DOM, it is not in a state
 * that can be interacted with. This includes an element that is not displayed or whose center point
 * can not be scrolled into the viewport.
 */
public class ElementNotInteractableException extends InvalidElementStateException {
  public ElementNotInteractableException(String message) {
    super(message);
  }

  public ElementNotInteractableException(String message, Throwable cause) {
    super(message, cause);
  }
}
