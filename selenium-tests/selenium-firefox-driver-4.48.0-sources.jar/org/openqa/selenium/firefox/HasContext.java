// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

package org.openqa.selenium.firefox;

import org.openqa.selenium.Beta;

/** Used by classes to indicate that they can change the context commands operate in. */
@Beta
public interface HasContext {

  /**
   * Context commands are operating on.
   *
   * @param context {@link FirefoxCommandContext} operating on page loaded in the browser or on
   *     browser elements hosting the page.
   */
  void setContext(FirefoxCommandContext context);

  /**
   * Current context commands are operating on.
   *
   * @return {@link FirefoxCommandContext} value currently operating on commands
   */
  FirefoxCommandContext getContext();
}
